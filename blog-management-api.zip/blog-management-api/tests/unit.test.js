// Database-independent HTTP tests: real Express routes, JWTs, bcrypt and validation;
// Mongoose persistence calls are mocked. These complement, not replace, api.test.js.
import { test, before } from 'node:test';
import assert from 'node:assert/strict';
import { randomBytes } from 'node:crypto';
import { spawnSync } from 'node:child_process';
import request from 'supertest';
import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';
import mongoose from 'mongoose';

process.env.NODE_ENV = 'test';
process.env.JWT_SECRET = randomBytes(48).toString('hex');
process.env.MONGODB_URI = 'mongodb://127.0.0.1:27017/unused_unit_tests';
process.env.CLIENT_ORIGINS = 'http://localhost:5173,http://localhost:5000';
process.env.TRUST_PROXY_HOPS = '0';
const { createApp } = await import('../src/app.js');
const { User } = await import('../src/models/User.js');
const { Blog } = await import('../src/models/Blog.js');
const { Session } = await import('../src/models/Session.js');
const schemas = await import('../src/validators/schemas.js');

const csrf = 'a'.repeat(64);
const password = 'ExamplePass123!';
const userData = { name: 'Alice Author', email: 'alice@example.com', phoneNumber: '+8801700000001' };
const blogData = { title: 'My blog', content: 'Hello backend', authorName: 'Alice Author', tags: ['node'], blogImage: 'https://example.com/a.png' };
let passwordHash;
before(async () => { passwordHash = await bcrypt.hash(password, 12); });

function authorize(t) {
  const user = new User({ ...userData, password: passwordHash });
  const session = new Session({ user: user._id, csrfToken: csrf, expiresAt: new Date(Date.now() + 60000) });
  const token = jwt.sign({ sid: session.id }, process.env.JWT_SECRET, {
    subject: user.id, issuer: 'blog-management-api', audience: 'blog-management-client', expiresIn: 60,
  });
  const sessions = t.mock.method(Session, 'findOne', () => ({ select: async () => session }));
  t.mock.method(User, 'findById', async () => user);
  return { app: createApp(), user, session, cookie: `blog_session=${token}`, sessions };
}

test('validators normalize fields and reject invalid registration input', () => {
  const value = schemas.registerSchema.parse({ ...userData, email: ' ALICE@EXAMPLE.COM ', password });
  assert.equal(value.email, 'alice@example.com');
  for (const body of [{ ...userData, password: 'short' }, { ...userData, password: 'গ'.repeat(25) },
    { ...userData, password, role: 'admin' }, { ...userData, password, email: { $ne: null } }]) {
    assert.equal(schemas.registerSchema.safeParse(body).success, false);
  }
});

test('blog schemas normalize tags and reject ownership injection, invalid URLs and empty updates', () => {
  assert.deepEqual(schemas.createBlogSchema.parse({ ...blogData, tags: [' Node ', 'node'] }).tags, ['node']);
  assert.deepEqual(schemas.createBlogSchema.parse({ ...blogData, tags: undefined }).tags, []);
  for (const body of [{}, { creator: new mongoose.Types.ObjectId().toString() }, { title: ' ' },
    { blogImage: 'javascript:alert(1)' }, { content: { $set: 'bad' } }, { tags: [''] }]) {
    assert.equal(schemas.updateBlogSchema.safeParse(body).success, false);
  }
  assert.deepEqual(schemas.listBlogsSchema.parse({}), { page: 1, limit: 10 });
  assert.equal(schemas.listBlogsSchema.safeParse({ page: 0 }).success, false);
});

test('all blog routes and profile endpoints require login', async () => {
  const app = createApp();
  const id = new mongoose.Types.ObjectId().toString();
  for (const [method, path, data] of [
    ['get', '/api/blogs'], ['get', `/api/blogs/${id}`], ['post', '/api/blogs', blogData],
    ['patch', `/api/blogs/${id}`, { title: 'changed' }], ['delete', `/api/blogs/${id}`, {}],
    ['get', '/api/users/me'], ['patch', '/api/users/me', { name: 'Changed' }],
  ]) {
    let req = request(app)[method](path);
    if (data) req = req.send(data);
    await req.expect(401);
  }
});

test('registration hashes the password and omits it from the response', async t => {
  let saved;
  t.mock.method(User, 'create', async data => { saved = data; return new User(data); });
  const res = await request(createApp()).post('/api/auth/register').send({ ...userData, password }).expect(201);
  assert.ok(await bcrypt.compare(password, saved.password));
  assert.notEqual(saved.password, password);
  assert.equal(res.body.data.user.password, undefined);
  assert.equal(res.headers['set-cookie'], undefined);
});

test('login uses a real JWT in an HttpOnly cookie and creates a revocable session', async t => {
  const user = new User({ ...userData, password: passwordHash });
  t.mock.method(User, 'findOne', () => ({ select: async () => user }));
  let saved;
  t.mock.method(Session, 'create', async data => { saved = new Session(data); return saved; });
  const res = await request(createApp()).post('/api/auth/login').send({ email: userData.email, password }).expect(200);
  const cookie = res.headers['set-cookie'][0];
  assert.match(cookie, /HttpOnly/);
  assert.match(cookie, /SameSite=Lax/);
  assert.match(cookie, /Path=\//);
  const token = cookie.split(';')[0].slice('blog_session='.length);
  const decoded = jwt.verify(token, process.env.JWT_SECRET, {
    algorithms: ['HS256'], audience: 'blog-management-client', issuer: 'blog-management-api',
  });
  assert.equal(decoded.sub, user.id);
  assert.equal(decoded.sid, saved.id);
  assert.equal(res.body.data.csrfToken, saved.csrfToken);
  assert.equal(res.body.data.user.password, undefined);
});

test('login returns the same error for unknown email and incorrect password', async t => {
  const lookup = t.mock.method(User, 'findOne', () => ({ select: async () => null }));
  const app = createApp();
  const first = await request(app).post('/api/auth/login').send({ email: userData.email, password }).expect(401);
  lookup.mock.mockImplementation(() => ({ select: async () => new User({ ...userData, password: passwordHash }) }));
  const second = await request(app).post('/api/auth/login').send({ email: userData.email, password: 'Incorrect123!' }).expect(401);
  assert.equal(first.body.message, second.body.message);
});

test('tampered, expired and wrong-algorithm JWTs are rejected', async () => {
  const app = createApp();
  const body = { sid: new mongoose.Types.ObjectId().toString() };
  const options = { subject: new mongoose.Types.ObjectId().toString(), issuer: 'blog-management-api', audience: 'blog-management-client' };
  for (const token of ['bad.jwt.token', jwt.sign(body, process.env.JWT_SECRET, { ...options, expiresIn: -1 }),
    jwt.sign(body, process.env.JWT_SECRET, { ...options, algorithm: 'HS384', expiresIn: 60 })]) {
    await request(app).get('/api/blogs').set('Cookie', `blog_session=${token}`).expect(401);
  }
});

test('session lookup requires matching user and future expiry; absent sessions are rejected', async t => {
  const auth = authorize(t);
  await request(auth.app).get('/api/users/me').set('Cookie', auth.cookie).expect(200);
  const filter = auth.sessions.mock.calls[0].arguments[0];
  assert.equal(filter.user, auth.user.id);
  assert.equal(filter._id, auth.session.id);
  assert.ok(filter.expiresAt.$gt instanceof Date);
  auth.sessions.mock.mockImplementation(() => ({ select: async () => null }));
  await request(auth.app).get('/api/users/me').set('Cookie', auth.cookie).expect(401);
});

test('profile update applies only valid fields and returns no password', async t => {
  const { app, user, cookie } = authorize(t);
  let saved = false;
  t.mock.method(user, 'save', async () => { saved = true; return user; });
  const response = await request(app).patch('/api/users/me').set('Cookie', cookie).set('X-CSRF-Token', csrf)
    .send({ name: 'Alice Updated', phoneNumber: '+8801800000000' }).expect(200);
  assert.ok(saved);
  assert.equal(response.body.data.user.name, 'Alice Updated');
  assert.equal(response.body.data.user.password, undefined);
  await request(app).patch('/api/users/me').set('Cookie', cookie).set('X-CSRF-Token', csrf).send({ password }).expect(400);
});

test('cookie mutations reject missing/wrong CSRF tokens and allow recovery via GET', async t => {
  const { app, cookie } = authorize(t);
  await request(app).post('/api/blogs').set('Cookie', cookie).send(blogData).expect(403);
  await request(app).post('/api/blogs').set('Cookie', cookie).set('X-CSRF-Token', 'invalid').send(blogData).expect(403);
  const response = await request(app).get('/api/auth/csrf').set('Cookie', cookie).expect(200);
  assert.equal(response.body.data.csrfToken, csrf);
});

test('blog creation sets owner from session and strips no required data', async t => {
  const { app, cookie, user } = authorize(t);
  let data;
  t.mock.method(Blog, 'create', async value => { data = value; return new Blog(value); });
  const response = await request(app).post('/api/blogs').set('Cookie', cookie).set('X-CSRF-Token', csrf).send(blogData).expect(201);
  assert.equal(data.creator.toString(), user.id);
  assert.equal(response.body.data.blog.title, blogData.title);
  assert.equal(response.body.data.blog.blogImage, blogData.blogImage);
  await request(app).post('/api/blogs').set('Cookie', cookie).set('X-CSRF-Token', csrf)
    .send({ ...blogData, creator: new mongoose.Types.ObjectId().toString() }).expect(400);
});

test('list and detail return other authors’ blogs to authenticated readers', async t => {
  const { app, cookie } = authorize(t);
  const blog = new Blog({ ...blogData, creator: new mongoose.Types.ObjectId() });
  let seenFilter, seenSkip, seenLimit;
  t.mock.method(Blog, 'find', filter => {
    seenFilter = filter;
    return { sort: () => ({ skip: value => { seenSkip = value; return { limit: async limit => { seenLimit = limit; return [blog]; } }; } }) };
  });
  t.mock.method(Blog, 'countDocuments', async () => 12);
  t.mock.method(Blog, 'findById', async () => blog);
  const res = await request(app).get('/api/blogs?page=2&limit=5&tag=NODE').set('Cookie', cookie).expect(200);
  assert.deepEqual(seenFilter, { tags: 'node' });
  assert.equal(seenSkip, 5);
  assert.equal(seenLimit, 5);
  assert.equal(res.body.pagination.pages, 3);
  const detail = await request(app).get(`/api/blogs/${blog.id}`).set('Cookie', cookie).expect(200);
  assert.equal(detail.body.data.blog._id, blog.id);
});

test('non-creators cannot update or delete a blog', async t => {
  const { app, cookie } = authorize(t);
  const blog = new Blog({ ...blogData, creator: new mongoose.Types.ObjectId() });
  t.mock.method(Blog, 'findById', async () => blog);
  const update = t.mock.method(Blog, 'findOneAndUpdate', () => { throw new Error('Must not write'); });
  const deletion = t.mock.method(Blog, 'deleteOne', () => { throw new Error('Must not delete'); });
  await request(app).patch(`/api/blogs/${blog.id}`).set('Cookie', cookie).set('X-CSRF-Token', csrf).send({ title: 'Hijack' }).expect(403);
  await request(app).delete(`/api/blogs/${blog.id}`).set('Cookie', cookie).set('X-CSRF-Token', csrf).send({}).expect(403);
  assert.equal(update.mock.callCount(), 0);
  assert.equal(deletion.mock.callCount(), 0);
});

test('owner update and delete include the owner ID in database write filters', async t => {
  const { app, cookie, user } = authorize(t);
  const blog = new Blog({ ...blogData, creator: user._id });
  t.mock.method(Blog, 'findById', async () => blog);
  t.mock.method(Blog, 'findOneAndUpdate', async (filter, update, options) => {
    assert.equal(filter.creator.toString(), user.id);
    assert.equal(filter._id, blog.id);
    assert.equal(options.runValidators, true);
    Object.assign(blog, update.$set);
    return blog;
  });
  t.mock.method(Blog, 'deleteOne', async filter => {
    assert.equal(filter.creator.toString(), user.id);
    return { deletedCount: 1 };
  });
  const response = await request(app).patch(`/api/blogs/${blog.id}`).set('Cookie', cookie).set('X-CSRF-Token', csrf)
    .send({ title: 'Changed', tags: [] }).expect(200);
  assert.equal(response.body.data.blog.title, 'Changed');
  assert.deepEqual(response.body.data.blog.tags, []);
  await request(app).delete(`/api/blogs/${blog.id}`).set('Cookie', cookie).set('X-CSRF-Token', csrf).send({}).expect(200);
});

test('malformed IDs, absent blogs and duplicate emails map to expected HTTP errors', async t => {
  const { app, cookie } = authorize(t);
  t.mock.method(Blog, 'findById', async () => null);
  await request(app).get('/api/blogs/invalid-id').set('Cookie', cookie).expect(400);
  await request(app).get(`/api/blogs/${new mongoose.Types.ObjectId()}`).set('Cookie', cookie).expect(404);
  t.mock.method(User, 'create', async () => { throw Object.assign(new Error('duplicate'), { code: 11000 }); });
  await request(app).post('/api/auth/register').send({ ...userData, password }).expect(409);
});

test('logout deletes only the current session and clears the cookie; replay fails', async t => {
  const { app, cookie, user, session, sessions } = authorize(t);
  t.mock.method(Session, 'deleteOne', async filter => {
    assert.equal(filter._id.toString(), session.id);
    assert.equal(filter.user.toString(), user.id);
    sessions.mock.mockImplementation(() => ({ select: async () => null }));
    return { deletedCount: 1 };
  });
  const response = await request(app).post('/api/auth/logout').set('Cookie', cookie).set('X-CSRF-Token', csrf).send({}).expect(200);
  assert.match(response.headers['set-cookie'][0], /Expires=Thu, 01 Jan 1970/);
  await request(app).get('/api/blogs').set('Cookie', cookie).expect(401);
});

test('origin, JSON, body size, cache, and authentication rate limits are enforced', async () => {
  const app = createApp();
  await request(app).post('/api/auth/login').set('Origin', 'https://evil.example').send({}).expect(403);
  await request(app).post('/api/auth/login').type('form').send({}).expect(415);
  await request(app).post('/api/auth/login').type('json').send('{broken').expect(400);
  await request(app).post('/api/auth/login').send({ data: 'x'.repeat(300000) }).expect(413);
  const response = await request(app).get('/api/blogs').set('Origin', 'http://localhost:5173').expect(401);
  assert.equal(response.headers['cache-control'], 'no-store');
  assert.equal(response.headers['access-control-allow-credentials'], 'true');
  assert.equal(response.headers['x-powered-by'], undefined);
  for (let i = 0; i < 20; i++) await request(app).post('/api/auth/login').send({}).expect(400);
  await request(app).post('/api/auth/login').send({}).expect(429);
});

test('production configuration uses Secure, HttpOnly, host-only cookies', () => {
  const res = spawnSync(process.execPath, ['--input-type=module', '-e',
    "import {cookieName,cookieOptions} from './src/config/env.js'; console.log(JSON.stringify({cookieName,cookieOptions}));"],
  { encoding: 'utf8', env: { ...process.env, NODE_ENV: 'production' } });
  assert.equal(res.status, 0, res.stderr);
  const config = JSON.parse(res.stdout.trim());
  assert.equal(config.cookieName, '__Host-blog_session');
  assert.equal(config.cookieOptions.secure, true);
  assert.equal(config.cookieOptions.httpOnly, true);
  assert.equal(config.cookieOptions.domain, undefined);
});
