import { before, after, beforeEach, test } from 'node:test';
import assert from 'node:assert/strict';
import { randomBytes } from 'node:crypto';
import { spawnSync } from 'node:child_process';
import request from 'supertest';
import { MongoMemoryServer } from 'mongodb-memory-server';
import mongoose from 'mongoose';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';

let mongod, app, createApp, User, Blog, Session, alice, bob, passwordHash;
const password = 'ExamplePass123!';
const aliceInput = { name: 'Alice Author', email: 'alice@example.com', password, phoneNumber: '+8801700000001' };
const bobInput = { name: 'Bob Reader', email: 'bob@example.com', password, phoneNumber: '+8801700000002' };
const blogInput = { title: 'Learning Express', content: 'My first protected blog post.', authorName: 'Alice Author', tags: ['Node', 'Express', 'node'], blogImage: 'https://example.com/blog.jpg' };

before(async () => {
  process.env.NODE_ENV = 'test';
  process.env.JWT_SECRET = randomBytes(48).toString('hex');
  process.env.CLIENT_ORIGINS = 'http://localhost:5173,http://localhost:5000';
  process.env.TRUST_PROXY_HOPS = '0';
  process.env.JWT_TTL_SECONDS = '86400';
  // A separately named database prevents tests touching the development database.
  const dbName = `blog_test_${randomBytes(8).toString('hex')}`;
  if (process.env.TEST_MONGODB_URI) {
    const uri = new URL(process.env.TEST_MONGODB_URI);
    uri.pathname = `/${dbName}`;
    process.env.MONGODB_URI = uri.toString();
  } else {
    mongod = await MongoMemoryServer.create();
    process.env.MONGODB_URI = mongod.getUri(dbName);
  }
  ({ createApp } = await import('../src/app.js'));
  ({ User } = await import('../src/models/User.js'));
  ({ Blog } = await import('../src/models/Blog.js'));
  ({ Session } = await import('../src/models/Session.js'));
  const { connectDatabase } = await import('../src/config/database.js');
  await connectDatabase();
  passwordHash = await bcrypt.hash(password, 12);
}, { timeout: 180000 });

beforeEach(async () => {
  await Promise.all([User.deleteMany({}), Blog.deleteMany({}), Session.deleteMany({})]);
  [alice, bob] = await User.create([
    { ...aliceInput, password: passwordHash }, { ...bobInput, password: passwordHash },
  ]);
  app = createApp();
});

after(async () => {
  if (mongoose.connection.readyState === 1) await mongoose.connection.dropDatabase();
  await mongoose.disconnect();
  await mongod?.stop();
});

async function loggedIn(input = aliceInput) {
  const agent = request.agent(app);
  const response = await agent.post('/api/auth/login').send({ email: input.email, password }).expect(200);
  return { agent, csrf: response.body.data.csrfToken, response };
}
async function seedBlog() {
  return Blog.create({ ...blogInput, tags: ['node', 'express'], creator: alice._id });
}

test('registration normalizes email, hashes password, omits credentials and does not log in', async () => {
  const input = { ...aliceInput, email: ' NEW@Example.com ' };
  const response = await request(app).post('/api/auth/register').send(input).expect(201);
  assert.equal(response.body.data.user.email, 'new@example.com');
  assert.equal(response.body.data.user.password, undefined);
  assert.equal(response.headers['set-cookie'], undefined);
  const saved = await User.findOne({ email: 'new@example.com' }).select('+password');
  assert.notEqual(saved.password, password);
  assert.ok(await bcrypt.compare(password, saved.password));
});

test('registration rejects duplicate email case-insensitively', async () => {
  await request(app).post('/api/auth/register').send({ ...aliceInput, email: 'ALICE@example.com' }).expect(409);
});

test('registration rejects missing fields, injection, weak and oversized UTF-8 passwords', async () => {
  for (const body of [
    { name: 'Only Name' }, { ...aliceInput, email: { $ne: null } },
    { ...aliceInput, password: 'short' }, { ...aliceInput, password: 'গ'.repeat(25) },
    { ...aliceInput, role: 'admin' }, { ...aliceInput, phoneNumber: 'abc' },
  ]) await request(app).post('/api/auth/register').send(body).expect(400);
});

test('login sets an HttpOnly JWT cookie and returns the current profile with no password', async () => {
  const { agent, response, csrf } = await loggedIn();
  const cookie = response.headers['set-cookie'][0];
  assert.match(cookie, /HttpOnly/);
  assert.match(cookie, /SameSite=Lax/);
  assert.match(cookie, /Path=\//);
  assert.equal(csrf.length, 64);
  assert.equal(response.body.data.user.password, undefined);
  const profile = await agent.get('/api/users/me').expect(200);
  assert.equal(profile.body.data.user._id, alice.id);
  assert.equal(profile.body.data.user.password, undefined);
});

test('invalid login is generic for unknown email and wrong password', async () => {
  const first = await request(app).post('/api/auth/login').send({ email: aliceInput.email, password: 'Incorrect123!' }).expect(401);
  const second = await request(app).post('/api/auth/login').send({ email: 'unknown@example.com', password }).expect(401);
  assert.equal(first.body.message, second.body.message);
});

test('every blog operation and profile access rejects an anonymous client', async () => {
  const id = new mongoose.Types.ObjectId().toString();
  for (const [method, path, body] of [
    ['get', '/api/blogs'], ['get', `/api/blogs/${id}`], ['post', '/api/blogs', blogInput],
    ['patch', `/api/blogs/${id}`, { title: 'Changed' }], ['delete', `/api/blogs/${id}`, {}],
    ['get', '/api/users/me'], ['patch', '/api/users/me', { name: 'Changed' }],
  ]) {
    let req = request(app)[method](path);
    if (body) req = req.send(body);
    await req.expect(401);
  }
});

test('tampered, expired, wrong-algorithm and unbacked JWTs cannot access blogs', async () => {
  const sign = (options = {}) => jwt.sign({ sid: new mongoose.Types.ObjectId().toString() }, process.env.JWT_SECRET, {
    subject: alice.id, issuer: 'blog-management-api', audience: 'blog-management-client', expiresIn: 60, ...options,
  });
  for (const token of ['invalid.jwt.token', sign({ expiresIn: -1 }), sign({ algorithm: 'HS384' }), sign()]) {
    await request(app).get('/api/blogs').set('Cookie', `blog_session=${token}`).expect(401);
  }
});

test('profile update persists allowed fields and rejects protected fields', async () => {
  const { agent, csrf } = await loggedIn();
  const response = await agent.patch('/api/users/me').set('X-CSRF-Token', csrf)
    .send({ name: 'Alice Updated', email: 'UPDATED@example.com', phoneNumber: '+8801800000000' }).expect(200);
  assert.equal(response.body.data.user.email, 'updated@example.com');
  assert.equal((await User.findById(alice.id)).name, 'Alice Updated');
  for (const data of [{ password: 'ChangedPassword123!' }, { _id: bob.id }, {}, { email: bobInput.email }]) {
    await agent.patch('/api/users/me').set('X-CSRF-Token', csrf).send(data).expect(data.email ? 409 : 400);
  }
});

test('cookie mutations require the matching CSRF token; GET can retrieve it after reload', async () => {
  const { agent, csrf } = await loggedIn();
  await agent.post('/api/blogs').send(blogInput).expect(403);
  await agent.patch('/api/users/me').set('X-CSRF-Token', 'incorrect').send({ name: 'Changed' }).expect(403);
  const token = await agent.get('/api/auth/csrf').expect(200);
  assert.equal(token.body.data.csrfToken, csrf);
  await agent.post('/api/blogs').set('X-CSRF-Token', csrf).send(blogInput).expect(201);
});

test('CSRF tokens from another session are rejected', async () => {
  const first = await loggedIn();
  const second = await loggedIn(bobInput);
  await second.agent.post('/api/blogs').set('X-CSRF-Token', first.csrf).send(blogInput).expect(403);
});

test('create persists all blog fields, normalizes tags, and sets ownership on the server', async () => {
  const { agent, csrf } = await loggedIn();
  const response = await agent.post('/api/blogs').set('X-CSRF-Token', csrf).send(blogInput).expect(201);
  const blog = response.body.data.blog;
  assert.equal(blog.title, blogInput.title);
  assert.equal(blog.content, blogInput.content);
  assert.equal(blog.authorName, blogInput.authorName);
  assert.equal(blog.blogImage, blogInput.blogImage);
  assert.equal(blog.creator, alice.id);
  assert.deepEqual(blog.tags, ['node', 'express']);
  assert.equal(await Blog.countDocuments(), 1);
  await agent.post('/api/blogs').set('X-CSRF-Token', csrf).send({ ...blogInput, creator: bob.id }).expect(400);
});

test('all logged-in users can list and read each other’s blogs; pagination and tag filters work', async () => {
  const blog = await seedBlog();
  await Blog.create({ ...blogInput, title: 'Second post', tags: ['design'], creator: bob._id });
  const { agent } = await loggedIn(bobInput);
  const response = await agent.get('/api/blogs?limit=1&page=1').expect(200);
  assert.equal(response.body.pagination.total, 2);
  assert.equal(response.body.pagination.pages, 2);
  assert.equal(response.body.data.blogs.length, 1);
  const filtered = await agent.get('/api/blogs?tag=NODE').expect(200);
  assert.equal(filtered.body.data.blogs[0]._id, blog.id);
  const single = await agent.get(`/api/blogs/${blog.id}`).expect(200);
  assert.equal(single.body.data.blog.creator, alice.id);
});

test('only creator can update or delete, even if another user adopts the same display name', async () => {
  const blog = await seedBlog();
  const { agent, csrf } = await loggedIn(bobInput);
  await agent.patch('/api/users/me').set('X-CSRF-Token', csrf).send({ name: aliceInput.name }).expect(200);
  await agent.patch(`/api/blogs/${blog.id}`).set('X-CSRF-Token', csrf).send({ title: 'Hijacked' }).expect(403);
  await agent.delete(`/api/blogs/${blog.id}`).set('X-CSRF-Token', csrf).send({}).expect(403);
  assert.equal((await Blog.findById(blog.id)).title, blogInput.title);
});

test('creator can update all editable fields, clear tags, and delete their post', async () => {
  const blog = await seedBlog();
  const { agent, csrf } = await loggedIn();
  const response = await agent.patch(`/api/blogs/${blog.id}`).set('X-CSRF-Token', csrf)
    .send({ title: 'Updated', content: 'New content', authorName: 'Pen name', tags: [], blogImage: 'https://example.com/new.png' }).expect(200);
  assert.equal(response.body.data.blog.creator, alice.id);
  assert.equal(response.body.data.blog.title, 'Updated');
  assert.deepEqual(response.body.data.blog.tags, []);
  await agent.delete(`/api/blogs/${blog.id}`).set('X-CSRF-Token', csrf).send({}).expect(200);
  await agent.get(`/api/blogs/${blog.id}`).expect(404);
  assert.equal(await Blog.countDocuments(), 0);
});

test('blog validation rejects blanks, invalid images, ownership changes and empty updates', async () => {
  const blog = await seedBlog();
  const { agent, csrf } = await loggedIn();
  for (const data of [{}, { title: '  ' }, { blogImage: 'javascript:alert(1)' }, { blogImage: 'ftp://example.com/a.jpg' },
    { creator: bob.id }, { content: { $set: 'bad' } }, { tags: [''] }]) {
    await agent.patch(`/api/blogs/${blog.id}`).set('X-CSRF-Token', csrf).send(data).expect(400);
  }
  await agent.post('/api/blogs').set('X-CSRF-Token', csrf).send({ title: 'Missing fields' }).expect(400);
});

test('invalid IDs, missing records and invalid pagination return clear client errors', async () => {
  const { agent, csrf } = await loggedIn();
  await agent.get('/api/blogs/not-an-id').expect(400);
  const missing = new mongoose.Types.ObjectId().toString();
  await agent.get(`/api/blogs/${missing}`).expect(404);
  await agent.patch(`/api/blogs/${missing}`).set('X-CSRF-Token', csrf).send({ title: 'Updated' }).expect(404);
  await agent.delete(`/api/blogs/${missing}`).set('X-CSRF-Token', csrf).send({}).expect(404);
  for (const query of ['page=0', 'limit=101', 'page=abc', 'page[$gt]=0']) {
    await agent.get(`/api/blogs?${query}`).expect(400);
  }
});

test('logout invalidates the JWT session on the server and clears its cookie', async () => {
  const { agent, csrf, response } = await loggedIn();
  const copiedCookie = response.headers['set-cookie'][0].split(';')[0];
  const logout = await agent.post('/api/auth/logout').set('X-CSRF-Token', csrf).send({}).expect(200);
  assert.match(logout.headers['set-cookie'][0], /Expires=Thu, 01 Jan 1970/);
  await agent.get('/api/blogs').expect(401);
  await request(app).get('/api/blogs').set('Cookie', copiedCookie).expect(401);
});

test('logging out one session leaves another session active', async () => {
  const one = await loggedIn();
  const two = await loggedIn();
  await one.agent.post('/api/auth/logout').set('X-CSRF-Token', one.csrf).send({}).expect(200);
  await two.agent.get('/api/blogs').expect(200);
});

test('expired database session and deleted user are rejected immediately', async () => {
  const first = await loggedIn();
  await Session.updateMany({}, { $set: { expiresAt: new Date(Date.now() - 1000) } });
  await first.agent.get('/api/blogs').expect(401);
  const second = await loggedIn();
  await User.deleteOne({ _id: alice._id });
  await second.agent.get('/api/blogs').expect(401);
});

test('CORS permits configured origins and rejects untrusted browser origins', async () => {
  const response = await request(app).get('/api/health').set('Origin', 'http://localhost:5173').expect(200);
  assert.equal(response.headers['access-control-allow-origin'], 'http://localhost:5173');
  assert.equal(response.headers['access-control-allow-credentials'], 'true');
  await request(app).post('/api/auth/login').set('Origin', 'https://evil.example').send({ email: aliceInput.email, password }).expect(403);
  await request(app).get('/api/health').set('Origin', 'null').expect(403);
});

test('JSON-only writes, malformed JSON, body limit, 404 and cache headers work', async () => {
  await request(app).post('/api/auth/login').type('form').send({ email: aliceInput.email, password }).expect(415);
  await request(app).post('/api/auth/login').set('Content-Type', 'application/json').send('{broken').expect(400);
  await request(app).post('/api/auth/login').send({ value: 'x'.repeat(300000) }).expect(413);
  await request(app).get('/api/unknown').expect(404);
  const response = await request(app).get('/api/blogs').expect(401);
  assert.equal(response.headers['cache-control'], 'no-store');
  assert.equal(response.body.stack, undefined);
  assert.equal(response.headers['x-powered-by'], undefined);
});

test('failed authentication attempts are rate limited', async () => {
  for (let i = 0; i < 20; i++) await request(app).post('/api/auth/login').send({}).expect(400);
  await request(app).post('/api/auth/login').send({}).expect(429);
});

test('production uses a Secure host-only session cookie', () => {
  const result = spawnSync(process.execPath, ['--input-type=module', '-e',
    "import { cookieName, cookieOptions } from './src/config/env.js'; console.log(JSON.stringify({ cookieName, cookieOptions }));"],
  { cwd: process.cwd(), encoding: 'utf8', env: { ...process.env, NODE_ENV: 'production' } });
  assert.equal(result.status, 0, result.stderr);
  const value = JSON.parse(result.stdout.trim());
  assert.equal(value.cookieName, '__Host-blog_session');
  assert.equal(value.cookieOptions.secure, true);
  assert.equal(value.cookieOptions.httpOnly, true);
  assert.equal(value.cookieOptions.domain, undefined);
});
