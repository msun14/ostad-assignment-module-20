import { randomBytes } from 'node:crypto';
import { readFileSync, writeFileSync } from 'node:fs';

const example = new URL('../.env.example', import.meta.url);
const target = new URL('../.env', import.meta.url);
try {
  const content = readFileSync(example, 'utf8').replace('REPLACE_WITH_A_RANDOM_SECRET_AT_LEAST_32_CHARACTERS', randomBytes(48).toString('hex'));
  writeFileSync(target, content, { flag: 'wx', mode: 0o600 });
  console.log('Created .env with a random JWT secret. Check MONGODB_URI, then run npm run dev.');
} catch (error) {
  if (error.code === 'EEXIST') console.log('.env already exists and was left unchanged.');
  else throw error;
}
