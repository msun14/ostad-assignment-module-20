# Blog Management System — Backend API

A complete JavaScript assignment using **Node.js, Express 5, MongoDB/Mongoose, and JWT authentication in an HttpOnly cookie**.

All blog routes require login. Any logged-in user can read all blogs; only a blog's creator can update or delete it. The project includes validation, session revocation, CSRF protection, automated integration tests, and a Postman collection.

## 1. Requirements

- Node.js **22.13 or newer** (Node 24 is also supported).
- MongoDB running locally, a MongoDB Atlas connection, or Docker for the included local database configuration.
- A terminal and optionally Postman.

## 2. Start the project

Extract the ZIP, open a terminal in `blog-management-api`, then run:

```bash
npm ci
npm run setup
```

`npm run setup` creates `.env` with a fresh, randomly generated JWT secret. It never overwrites an existing `.env`. Open `.env` and check `MONGODB_URI`.

**Choose one database setup:**

- If MongoDB is installed locally, start its service. The default URI is `mongodb://127.0.0.1:27017/blog_management`.
- If Docker is installed, run `docker compose up -d` in this project. The included MongoDB container stores data in a persistent volume and exposes its port only on localhost.
- If using Atlas, replace `MONGODB_URI` in `.env` with your Atlas connection string, including a database name. Configure the database user and network access in Atlas. URL-encode special characters in connection-string credentials.

Start the API:

```bash
npm run dev
```

API base URL: `http://localhost:5000/api`

Check the server and database at `http://localhost:5000/api/health`.

For normal execution without automatic restarts:

```bash
npm start
```

## 3. Try the APIs in Postman

1. Import `postman/Blog-Management.postman_collection.json`.
2. Import `postman/Local.postman_environment.json` and select **Blog API — Local**.
3. Run the requests in their numbered order, or run the entire collection.

The collection creates fresh example email addresses on each run. Postman keeps the JWT cookie automatically. Login scripts save the `csrfToken`, and Create Blog saves `blogId`. Later requests use those variables automatically.

The last requests log in as a second user, verify that they can read the first user's blog, verify that editing and deletion are denied, then log back in as the owner to delete the post and log out.

Registration creates an account; **login is a separate request**.

## 4. Endpoint overview

| Method | Endpoint | Authentication | Purpose |
| --- | --- | --- | --- |
| GET | `/api/health` | Public | API/database health |
| POST | `/api/auth/register` | Public | Register a user |
| POST | `/api/auth/login` | Public | Set JWT cookie and return CSRF token |
| GET | `/api/auth/csrf` | Cookie | Recover the session's CSRF token after a reload |
| POST | `/api/auth/logout` | Cookie + CSRF | Revoke current session and clear cookie |
| GET | `/api/users/me` | Cookie | Get logged-in user's profile |
| PATCH | `/api/users/me` | Cookie + CSRF | Update name, email, phoneNumber |
| POST | `/api/blogs` | Cookie + CSRF | Create a blog |
| GET | `/api/blogs` | Cookie | Read all blogs, with pagination |
| GET | `/api/blogs/:id` | Cookie | Read one blog |
| PATCH | `/api/blogs/:id` | Cookie + CSRF + creator | Update a blog |
| DELETE | `/api/blogs/:id` | Cookie + CSRF + creator | Delete a blog |

All write requests use `Content-Type: application/json`. Send `{}` as the body for logout and deletion.

See [docs/API.md](docs/API.md) for request bodies, response examples, validation, and frontend usage.

## 5. Project structure

| Location | Responsibility |
| --- | --- |
| `src/server.js` | Connect database, start server, handle shutdown |
| `src/app.js` | Assemble Express and middleware |
| `src/config/` | Environment settings and database connection |
| `src/models/` | User, Blog, and Session MongoDB schemas |
| `src/routes/` | Map HTTP routes to middleware and controllers |
| `src/controllers/` | Authentication, profile, and blog operations |
| `src/middleware/` | Authentication, validation, CSRF, limits, error handling |
| `src/validators/` | Zod request schemas and field rules |
| `src/utils/` | Shared errors and session/JWT creation |
| `scripts/` | Environment setup and JavaScript syntax check |
| `tests/api.test.js` | Integration tests against real temporary MongoDB |
| `tests/unit.test.js` | Database-independent HTTP tests with mocked persistence |
| `postman/` | Importable collection and local environment |
| `docs/API.md` | API contract and browser example |
| `docs/TEST-RESULTS.md` | Verification record for this delivery |
| `compose.yaml` | Optional local MongoDB container |
| `.env.example` | Configuration template; no live credentials |
| `package-lock.json` | Reproducible dependency versions |

Request flow: route → authentication/CSRF → validation → controller → model → JSON response. Express 5 forwards rejected async handlers to the central error middleware.

## 6. Run tests

```bash
npm run check
npm test
```

Tests use `mongodb-memory-server`, which launches a real temporary MongoDB process. The first run downloads a MongoDB binary and needs internet access. It does not use or erase your development database.

To run only the database-independent tests:

```bash
npm run test:unit
```

These execute the real Express routes, JWT verification, bcrypt and validation, with Mongoose persistence calls mocked. For this delivery, all 18 of these tests passed. The 23 real-MongoDB integration tests could not run in the build environment because the MongoDB process was blocked at startup. Run `npm test` locally to complete that verification; see [docs/TEST-RESULTS.md](docs/TEST-RESULTS.md).

If downloads are blocked, you can provide an existing MongoDB server. Tests create a uniquely named test database and drop only that database afterward.

macOS/Linux:

```bash
TEST_MONGODB_URI=mongodb://127.0.0.1:27017 npm test
```

Windows PowerShell:

```powershell
$env:TEST_MONGODB_URI="mongodb://127.0.0.1:27017"
npm test
Remove-Item Env:TEST_MONGODB_URI
```

The test MongoDB account must be allowed to create and drop that temporary database. Integration tests cover successful requests as well as access restrictions and invalid input.

## 7. Design decisions

- **blogImage is an HTTP/HTTPS URL.** Upload the actual image to your preferred image host separately. The API stores the URL; it does not download, verify image contents, or accept multipart uploads.
- **authorName is a display byline.** It may be a pen name. Ownership is stored independently in `creator` from the authenticated user's ID, so changing a name cannot transfer ownership.
- **Profile updates** support `name`, `email`, and `phoneNumber`. Password changes/reset and email verification are outside the assignment and are not implemented.
- **List pagination** defaults to 10 posts per page and allows up to 100; use `page`, `limit`, and optional `tag`. Logged-in users can access every page of available blogs.
- **Cookie-only authentication.** The JWT is stored in the HttpOnly cookie and never returned as a JSON access token. Bearer-header authentication is not implemented.
- **Sessions are stored in MongoDB** so logout revokes the JWT immediately. Expired sessions are rejected on every request, even before MongoDB's TTL cleanup removes their documents.
- **CSRF tokens** protect authenticated write operations. Login returns one; `GET /api/auth/csrf` retrieves it after a reload. No CSRF token is needed for GET requests or initial registration/login.
- User passwords use bcrypt with cost 12. Registration accepts at least 8 characters and no more than 72 UTF-8 bytes, avoiding bcrypt's silent truncation.
- Blog content is plain text data. A frontend should display it as text, or sanitize it before rendering it as HTML.

## 8. Deployment settings

Use HTTPS and `NODE_ENV=production`. Production cookies are Secure, HttpOnly, SameSite=Lax, and use the host-only `__Host-blog_session` name. Development uses `blog_session` so localhost HTTP works.

Set `CLIENT_ORIGINS` to exact frontend origins, separated by commas, without trailing slashes. Browser requests must use `credentials: 'include'`. The defaults support a frontend at `http://localhost:5173`. Use the same hostname consistently; do not mix `localhost` and `127.0.0.1` in browser API URLs.

The current SameSite=Lax cookie configuration is intended for a same-site frontend/API (including localhost on different ports). An unrelated cross-site frontend requires an intentional cookie/CORS configuration change; merely adding its origin will not make browsers send this cookie.

Only set `TRUST_PROXY_HOPS` when the deployment's exact proxy topology is known. The default is 0. The included rate limiter uses process memory, suitable for a single instance; multiple instances need a shared limiter store. The local Docker database is a development helper; use a secured database service for deployment.

## 9. Troubleshooting

| Problem | Fix |
| --- | --- |
| Configuration error | Run `npm run setup`, then check `.env` against `.env.example` |
| Database connection fails | Start MongoDB/Docker, or check Atlas URI, credentials, and network access |
| 401 on blog routes | Log in, keep the cookie, and use `credentials: 'include'` in browser requests |
| 403 mentioning CSRF | Send the current session's `X-CSRF-Token`; it changes after a new login |
| 403 mentioning creator | Log in as the account that created the blog |
| 403 mentioning origin | Match the browser origin exactly in `CLIENT_ORIGINS` |
| 415 on a write | Set JSON content type and use `{}` for an empty body |
| 409 on registration/profile | That email is already used |
| 429 | Wait for the 15-minute rate-limit window to reset |
| Test binary download fails | Set `TEST_MONGODB_URI` to a running MongoDB server |

## References

- [Express 5 middleware and async error forwarding](https://expressjs.com/en/guide/writing-middleware/)
- [Mongoose validation and unique indexes](https://mongoosejs.com/docs/validation.html)
- [jsonwebtoken documentation](https://www.npmjs.com/package/jsonwebtoken)

No frontend is needed for this backend assignment. The ZIP contains source and project files; install dependencies with `npm ci`.
