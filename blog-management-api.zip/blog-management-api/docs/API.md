# API usage

Base URL: `http://localhost:5000/api`

All request/response bodies are JSON. Object IDs are 24-character hexadecimal strings. Dates are ISO 8601 strings. User responses never include passwords or password hashes.

## Authentication workflow

1. Register an account.
2. Log in. Save cookies in your HTTP client and retain `data.csrfToken`.
3. Send the cookie on protected requests.
4. Add `X-CSRF-Token` to POST/PATCH/DELETE requests after login.
5. Log out to revoke the current session.

Login/registration accept JSON only and reject unapproved browser origins. All blog routes, including list and detail, require authentication. CORS preflight OPTIONS is supported without logging in and returns no blog data.

## Register

`POST /auth/register`

```json
{
  "name": "Barath",
  "email": "barath@example.com",
  "password": "ExamplePass123!",
  "phoneNumber": "+8801700000000"
}
```

Returns **201** with `data.user`. Registration does not automatically log you in. Duplicate email returns **409**.

## Log in

`POST /auth/login`

```json
{
  "email": "barath@example.com",
  "password": "ExamplePass123!"
}
```

Returns **200**, sets the session cookie, and returns:

```json
{
  "success": true,
  "message": "Login successful",
  "data": {
    "user": {
      "_id": "507f1f77bcf86cd799439011",
      "name": "Barath",
      "email": "barath@example.com",
      "phoneNumber": "+8801700000000",
      "createdAt": "2026-10-01T00:00:00.000Z",
      "updatedAt": "2026-10-01T00:00:00.000Z"
    },
    "csrfToken": "session-specific-token-returned-by-the-server"
  }
}
```

The example ID, timestamps, and CSRF token above are illustrative. Use actual returned values. The default session lifetime is 24 hours; the JWT and database expiry both enforce it. Logging in again creates a separate session.

## Current profile

`GET /users/me` → **200**, `data.user`.

`PATCH /users/me` → **200**, updated `data.user`.

```json
{
  "name": "Barath Designer",
  "phoneNumber": "+8801800000000"
}
```

You may update `name`, `email`, and/or `phoneNumber`. An empty object or unknown field is rejected. Password/ID updates are not supported.

## Create blog

`POST /blogs` → **201**, `data.blog`.

```json
{
  "title": "My first backend project",
  "content": "Today I learned how to protect Express routes using JWT cookies.",
  "authorName": "Barath",
  "tags": ["JavaScript", "Backend"],
  "blogImage": "https://example.com/my-blog-cover.jpg"
}
```

The image URL is an example; replace it with an actual hosted image URL. `tags` may be omitted and will default to `[]`. Tags are trimmed, lowercased, and deduplicated. All other shown fields are required. The server sets `creator` from the session. Do not send `creator`, `_id`, or timestamps.

## Read blogs

`GET /blogs?page=1&limit=10&tag=javascript` → **200**.

```json
{
  "success": true,
  "data": { "blogs": [] },
  "pagination": { "page": 1, "limit": 10, "total": 0, "pages": 0 }
}
```

Results are newest first, with `_id` as a stable secondary sort. Each blog includes `_id`, `title`, `content`, `authorName`, `tags`, `blogImage`, `creator`, `createdAt`, and `updatedAt`. An empty database or page beyond the end returns an empty array.

`GET /blogs/:id` → **200**, `data.blog`; **404** if not found.

## Update or delete a blog

`PATCH /blogs/:id` → **200**, updated `data.blog`.

```json
{
  "title": "My updated backend project",
  "content": "I added validation and authorization tests.",
  "tags": ["node", "express", "mongodb"]
}
```

Provide at least one editable field. Omitted fields remain unchanged. Use `"tags": []` to clear tags. The creator cannot be changed.

`DELETE /blogs/:id` with JSON body `{}` → **200**:

```json
{ "success": true, "message": "Blog deleted" }
```

Both operations return **403** when the logged-in user is not the creator. The display byline has no effect on this check.

## CSRF recovery and logout

`GET /auth/csrf` → **200**, `data.csrfToken` for the current session.

`POST /auth/logout` with `X-CSRF-Token` and JSON body `{}` → **200**. The session is deleted from the database and the cookie is cleared. Replaying that JWT fails, while other sessions remain active.

## Validation rules

| Field | Rule |
| --- | --- |
| name, authorName | 2–80 characters, trimmed |
| email | Valid email, maximum 254 characters, trimmed/lowercased, unique |
| password at registration | At least 8 characters; at most 72 UTF-8 bytes |
| phoneNumber | 7–15 digits, optional leading `+`; no spaces/dashes |
| title | 1–200 characters after trimming |
| content | 1–50,000 characters after trimming |
| tags | At most 10 entries, each 1–30 characters |
| blogImage | HTTP/HTTPS URL, at most 2,048 characters, no URL credentials |
| page | Integer 1–100,000; default 1 |
| limit | Integer 1–100; default 10 |

Request objects reject unknown fields. The JSON body size limit is 256 KB. The general limit is 300 requests per 15 minutes per IP, and registration/login share a 20-failed-attempt limit per 15 minutes per IP.

## Error responses

```json
{
  "success": false,
  "message": "Validation failed",
  "errors": [{ "field": "title", "message": "Too small: expected string to have >=1 characters" }]
}
```

Validation wording can vary by dependency version. Always branch on HTTP status rather than exact message text.

| Status | Meaning |
| --- | --- |
| 400 | Invalid fields, ID, pagination, or malformed JSON |
| 401 | Missing/invalid/expired/revoked session, or invalid login |
| 403 | Wrong creator, missing/invalid CSRF token, or unapproved origin |
| 404 | Blog/route not found |
| 409 | Email already registered |
| 413 | Request body exceeds limit |
| 415 | Write request is not JSON, or unsupported encoding |
| 429 | Rate limit exceeded |
| 500 | Unexpected server failure; internal details are not returned |
| 503 | Health check reports unavailable database |

## Browser JavaScript example

Run this from an allowed frontend origin, such as `http://localhost:5173`. Register first using the same helper.

```js
const base = 'http://localhost:5000/api';
let csrfToken;

async function api(path, method = 'GET', body) {
  const headers = {};
  if (body !== undefined) headers['Content-Type'] = 'application/json';
  if (csrfToken && !['GET', 'HEAD'].includes(method)) {
    headers['X-CSRF-Token'] = csrfToken;
  }
  const response = await fetch(`${base}${path}`, {
    method,
    credentials: 'include',
    headers,
    ...(body === undefined ? {} : { body: JSON.stringify(body) }),
  });
  const result = await response.json();
  if (!response.ok) throw new Error(result.message);
  return result;
}

const login = await api('/auth/login', 'POST', {
  email: 'barath@example.com', password: 'ExamplePass123!',
});
csrfToken = login.data.csrfToken;

const created = await api('/blogs', 'POST', {
  title: 'Hello backend', content: 'My first protected post.',
  authorName: 'Barath', tags: ['node'],
  blogImage: 'https://example.com/cover.jpg',
});

const allBlogs = await api('/blogs');
await api(`/blogs/${created.data.blog._id}`, 'PATCH', { title: 'Updated title' });
await api(`/blogs/${created.data.blog._id}`, 'DELETE', {});
await api('/auth/logout', 'POST', {});
csrfToken = undefined;
```

After a page reload, retrieve `csrfToken` through `/auth/csrf` when the session cookie is still valid. Keep it in memory; JavaScript never needs to read the HttpOnly JWT cookie.
