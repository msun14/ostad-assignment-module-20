# Verification record

Verified on 2026-10-01 using Node.js 24.19.0 and npm 11.9.0.

| Check | Result |
| --- | --- |
| Dependency installation | Completed; package-lock.json included |
| `npm run check` | Passed: all 24 JavaScript files |
| `npm run test:unit` | Passed: 18 tests, 0 failures |
| Real-MongoDB integration suite | Blocked before test execution by MongoDB startup error |
| `npm audit --omit=dev --json` | 0 reported production dependency vulnerabilities at verification time |

## What the 18 passing tests verify

The tests use real Express routing/middleware, real JWT signing and verification, real bcrypt hashing/comparison, real Zod validation and Mongoose document serialization. Database queries and writes are mocked.

- Registration validation, normalization, password hashing, and password omission.
- Login cookie flags, signed JWT claims and session creation.
- Generic invalid-login errors.
- Authentication on every blog operation and profile access.
- Rejection of malformed, expired and wrong-algorithm JWTs.
- Database-session filter includes user ID and future expiry; a missing session fails authentication.
- Profile update whitelist.
- CSRF enforcement and token recovery.
- Server-controlled blog ownership and creation fields.
- Listing, pagination, tag filtering and reading other authors' posts.
- Creator-only editing/deletion and ownership-constrained write filters.
- Invalid IDs, missing blogs and duplicate-email error mapping.
- Logout cookie clearing and session revocation control flow.
- Origin restrictions, JSON-only writes, payload limit, cache headers and authentication rate limits.
- Production Secure/HttpOnly/host-only cookie configuration.

## MongoDB integration limitation

`mongodb-memory-server` attempted to launch MongoDB 7.0.24, but the build environment returned:

```text
std::exception in initAndListen, terminating
open: Operation not permitted
Instance closed unexpectedly with code "100"
```

The same startup error occurred with a workspace-local temporary database directory. Therefore no claim is made that the 23 integration cases passed. Real database persistence, index creation, duplicate-email enforcement and the complete workflow against MongoDB remain unverified in this environment.

The complete integration suite is provided in `tests/api.test.js`. Run `npm test` on a machine that permits a local MongoDB process, or set `TEST_MONGODB_URI` to a running MongoDB server as described in the README. Tests create a uniquely named database and drop only that database on completion.

Dependency audit results describe the registry's reported vulnerabilities at verification time; they do not guarantee the absence of every vulnerability.
