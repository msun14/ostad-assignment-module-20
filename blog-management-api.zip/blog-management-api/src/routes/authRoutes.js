import { Router } from 'express';
import { register, login, logout, getCsrf } from '../controllers/authController.js';
import { validate } from '../middleware/validate.js';
import { authenticate } from '../middleware/auth.js';
import { requireCsrf } from '../middleware/security.js';
import { registerSchema, loginSchema } from '../validators/schemas.js';

export function authRoutes(limiter) {
  const router = Router();
  router.post('/register', limiter, validate(registerSchema), register);
  router.post('/login', limiter, validate(loginSchema), login);
  router.get('/csrf', authenticate, getCsrf);
  router.post('/logout', authenticate, requireCsrf, logout);
  return router;
}
