import { Router } from 'express';
import { authenticate } from '../middleware/auth.js';
import { requireCsrf } from '../middleware/security.js';
import { validate } from '../middleware/validate.js';
import { profileSchema } from '../validators/schemas.js';
import { getProfile, updateProfile } from '../controllers/userController.js';

export const userRoutes = Router();
userRoutes.use(authenticate, requireCsrf);
userRoutes.get('/me', getProfile);
userRoutes.patch('/me', validate(profileSchema), updateProfile);
