import { Router } from 'express';
import { authenticate } from '../middleware/auth.js';
import { requireCsrf } from '../middleware/security.js';
import { validate } from '../middleware/validate.js';
import { createBlogSchema, updateBlogSchema, idSchema, listBlogsSchema } from '../validators/schemas.js';
import { createBlog, getAllBlogs, getBlog, updateBlog, deleteBlog } from '../controllers/blogController.js';

export const blogRoutes = Router();
// Every blog endpoint, including both GET endpoints, requires login.
blogRoutes.use(authenticate, requireCsrf);
blogRoutes.route('/').get(validate(listBlogsSchema, 'query'), getAllBlogs).post(validate(createBlogSchema), createBlog);
blogRoutes.route('/:id')
  .all(validate(idSchema, 'params'))
  .get(getBlog)
  .patch(validate(updateBlogSchema), updateBlog)
  .delete(deleteBlog);
