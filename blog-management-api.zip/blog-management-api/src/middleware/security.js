import { timingSafeEqual } from 'node:crypto';
import { rateLimit } from 'express-rate-limit';
import { allowedOrigins } from '../config/env.js';
import { ApiError } from '../utils/ApiError.js';

export function checkOrigin(req, res, next) {
  const origin = req.get('Origin');
  if (origin && !allowedOrigins.includes(origin)) return next(new ApiError(403, 'Origin is not allowed'));
  next();
}

// No form-encoded mutations: browser forms cannot silently submit this API.
export function requireJson(req, res, next) {
  if (['POST', 'PATCH', 'PUT', 'DELETE'].includes(req.method) && !req.is('application/json')) {
    return next(new ApiError(415, 'Use Content-Type: application/json; send {} for an empty body'));
  }
  next();
}

export function requireCsrf(req, res, next) {
  if (['GET', 'HEAD', 'OPTIONS'].includes(req.method)) return next();
  const supplied = Buffer.from(req.get('X-CSRF-Token') || '');
  const expected = Buffer.from(req.authSession.csrfToken);
  if (supplied.length !== expected.length || !timingSafeEqual(supplied, expected)) {
    return next(new ApiError(403, 'A valid X-CSRF-Token header is required'));
  }
  next();
}

export function createLimiters() {
  const common = { standardHeaders: 'draft-8', legacyHeaders: false };
  return {
    api: rateLimit({ ...common, windowMs: 15 * 60 * 1000, limit: 300,
      message: { success: false, message: 'Too many requests. Try again later.' } }),
    auth: rateLimit({ ...common, windowMs: 15 * 60 * 1000, limit: 20, skipSuccessfulRequests: true,
      message: { success: false, message: 'Too many authentication attempts. Try again later.' } }),
  };
}
