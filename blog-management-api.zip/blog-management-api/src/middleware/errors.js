import { env } from '../config/env.js';
import { ApiError } from '../utils/ApiError.js';

export const notFound = (req, res, next) => next(new ApiError(404, 'Route not found'));

export function errorHandler(error, req, res, next) {
  if (res.headersSent) return next(error);
  let status = error instanceof ApiError ? error.status : 500;
  let message = error instanceof ApiError ? error.message : 'Internal server error';
  if (error.code === 11000) { status = 409; message = 'This email is already registered'; }
  if (error.name === 'ValidationError' || error.name === 'CastError') { status = 400; message = 'Invalid data'; }
  if (error.type === 'entity.parse.failed') { status = 400; message = 'Invalid JSON body'; }
  if (error.type === 'entity.too.large') { status = 413; message = 'Request body is too large'; }
  if (error.type === 'encoding.unsupported' || error.type === 'charset.unsupported') { status = 415; message = 'Unsupported request encoding'; }
  if (status === 500 && env.NODE_ENV !== 'test') console.error('Request failed:', error.name);
  res.status(status).json({ success: false, message, ...(error.details ? { errors: error.details } : {}) });
}
