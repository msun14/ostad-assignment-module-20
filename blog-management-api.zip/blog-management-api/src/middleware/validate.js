import { ApiError } from '../utils/ApiError.js';

export const validate = (schema, source = 'body') => (req, res, next) => {
  const parsed = schema.safeParse(req[source]);
  if (!parsed.success) {
    return next(new ApiError(400, 'Validation failed', parsed.error.issues.map(issue => ({
      field: issue.path.join('.'), message: issue.message,
    }))));
  }
  req.validated ??= {};
  req.validated[source] = parsed.data;
  next();
};
