import jwt from 'jsonwebtoken';
import mongoose from 'mongoose';
import { env, cookieName } from '../config/env.js';
import { User } from '../models/User.js';
import { Session } from '../models/Session.js';
import { ApiError } from '../utils/ApiError.js';

export async function authenticate(req, res, next) {
  const token = req.cookies[cookieName];
  if (!token) throw new ApiError(401, 'Please log in to continue');
  let payload;
  try {
    payload = jwt.verify(token, env.JWT_SECRET, {
      algorithms: ['HS256'], issuer: 'blog-management-api', audience: 'blog-management-client',
    });
  } catch { throw new ApiError(401, 'Invalid or expired session. Please log in again'); }
  if (!mongoose.isObjectIdOrHexString(payload.sub) || !mongoose.isObjectIdOrHexString(payload.sid)) {
    throw new ApiError(401, 'Invalid session');
  }
  const session = await Session.findOne({
    _id: payload.sid, user: payload.sub, expiresAt: { $gt: new Date() },
  }).select('+csrfToken');
  if (!session) throw new ApiError(401, 'Session has ended. Please log in again');
  const user = await User.findById(payload.sub);
  if (!user) throw new ApiError(401, 'User no longer exists');
  req.user = user;
  req.authSession = session;
  next();
}
