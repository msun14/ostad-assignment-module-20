import mongoose from 'mongoose';

const blogSchema = new mongoose.Schema({
  title: { type: String, required: true, trim: true, maxlength: 200 },
  content: { type: String, required: true, maxlength: 50000 },
  authorName: { type: String, required: true, trim: true, maxlength: 80 },
  tags: { type: [String], default: [] },
  blogImage: { type: String, required: true, maxlength: 2048 },
  // Ownership is always taken from the authenticated user, never request input.
  creator: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, immutable: true },
}, { timestamps: true, versionKey: false });
blogSchema.index({ createdAt: -1, _id: -1 });
blogSchema.index({ creator: 1 });
blogSchema.index({ tags: 1 });
export const Blog = mongoose.model('Blog', blogSchema);
