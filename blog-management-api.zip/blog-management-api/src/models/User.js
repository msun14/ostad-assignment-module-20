import mongoose from 'mongoose';

const userSchema = new mongoose.Schema({
  name: { type: String, required: true, trim: true, minlength: 2, maxlength: 80 },
  email: { type: String, required: true, unique: true, lowercase: true, trim: true, maxlength: 254 },
  password: { type: String, required: true, select: false },
  phoneNumber: { type: String, required: true, trim: true },
}, { timestamps: true, versionKey: false });

// Explicit whitelist: credentials can never leak through JSON serialization.
userSchema.methods.toJSON = function () {
  return {
    _id: this._id, name: this.name, email: this.email, phoneNumber: this.phoneNumber,
    createdAt: this.createdAt, updatedAt: this.updatedAt,
  };
};
export const User = mongoose.model('User', userSchema);
