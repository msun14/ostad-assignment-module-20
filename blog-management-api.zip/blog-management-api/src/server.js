import mongoose from 'mongoose';
import { env } from './config/env.js';
import { connectDatabase } from './config/database.js';
import { createApp } from './app.js';

try {
  await connectDatabase();
  const server = createApp().listen(env.PORT, () => console.log(`Blog API running at http://localhost:${env.PORT}`));
  server.on('error', async error => {
    console.error(`Server could not start: ${error.code || error.name}`);
    await mongoose.disconnect();
    process.exitCode = 1;
  });
  let stopping = false;
  function shutdown() {
    if (stopping) return;
    stopping = true;
    const timeout = setTimeout(() => process.exit(1), 10000);
    timeout.unref();
    server.close(async () => {
      await mongoose.disconnect();
      clearTimeout(timeout);
    });
  }
  process.on('SIGTERM', shutdown);
  process.on('SIGINT', shutdown);
} catch (error) {
  console.error(`Startup failed (${error.name}). Check MongoDB and .env configuration.`);
  await mongoose.disconnect();
  process.exitCode = 1;
}
