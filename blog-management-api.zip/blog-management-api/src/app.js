import express from 'express';
import helmet from 'helmet';
import cors from 'cors';
import cookieParser from 'cookie-parser';
import mongoose from 'mongoose';
import { env, allowedOrigins } from './config/env.js';
import { checkOrigin, requireJson, createLimiters } from './middleware/security.js';
import { errorHandler, notFound } from './middleware/errors.js';
import { authRoutes } from './routes/authRoutes.js';
import { userRoutes } from './routes/userRoutes.js';
import { blogRoutes } from './routes/blogRoutes.js';

export function createApp() {
  const app = express();
  const limiters = createLimiters();
  app.disable('x-powered-by');
  app.set('trust proxy', env.TRUST_PROXY_HOPS);
  app.use(helmet());
  app.use(checkOrigin);
  app.use(cors({ origin: allowedOrigins, credentials: true,
    methods: ['GET', 'HEAD', 'POST', 'PATCH', 'DELETE', 'OPTIONS'],
    allowedHeaders: ['Content-Type', 'X-CSRF-Token'] }));
  app.use('/api', limiters.api, (req, res, next) => {
    res.set('Cache-Control', 'no-store');
    next();
  });
  app.use(express.json({ limit: '256kb' }));
  app.use(cookieParser());
  app.use('/api', requireJson);
  app.get('/api/health', (req, res) => {
    const connected = mongoose.connection.readyState === 1;
    res.status(connected ? 200 : 503).json({ success: connected, message: connected ? 'API is healthy' : 'Database is unavailable' });
  });
  app.use('/api/auth', authRoutes(limiters.auth));
  app.use('/api/users', userRoutes);
  app.use('/api/blogs', blogRoutes);
  app.use(notFound);
  app.use(errorHandler);
  return app;
}
