import 'dotenv/config';
import { z } from 'zod';

const schema = z.object({
  NODE_ENV: z.enum(['development', 'test', 'production']).default('development'),
  PORT: z.coerce.number().int().min(1).max(65535).default(5000),
  MONGODB_URI: z.string().regex(/^mongodb(?:\+srv)?:\/\//),
  JWT_SECRET: z.string().min(32).refine(value => !value.startsWith('REPLACE_'), 'Generate a secret with npm run setup'),
  JWT_TTL_SECONDS: z.coerce.number().int().min(60).max(604800).default(86400),
  CLIENT_ORIGINS: z.string().default('http://localhost:5173,http://localhost:5000'),
  TRUST_PROXY_HOPS: z.coerce.number().int().min(0).max(10).default(0),
});

const parsed = schema.safeParse(process.env);
if (!parsed.success) {
  const fields = parsed.error.issues.map(issue => `${issue.path.join('.')}: ${issue.message}`).join('; ');
  throw new Error(`Invalid configuration. ${fields}. See .env.example.`);
}
export const env = parsed.data;
export const allowedOrigins = env.CLIENT_ORIGINS.split(',').map(value => value.trim()).filter(Boolean);
if (!allowedOrigins.length || allowedOrigins.some(value => {
  try { return new URL(value).origin !== value || !/^https?:\/\//.test(value); }
  catch { return true; }
})) throw new Error('CLIENT_ORIGINS must contain exact http(s) origins without paths or trailing slashes.');

export const cookieName = env.NODE_ENV === 'production' ? '__Host-blog_session' : 'blog_session';
export const cookieOptions = {
  httpOnly: true,
  secure: env.NODE_ENV === 'production',
  sameSite: 'lax',
  path: '/',
};
