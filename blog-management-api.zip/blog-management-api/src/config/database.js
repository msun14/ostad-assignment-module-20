import mongoose from 'mongoose';
import { env } from './env.js';
import { User } from '../models/User.js';
import { Blog } from '../models/Blog.js';
import { Session } from '../models/Session.js';

export async function connectDatabase() {
  mongoose.set('strictQuery', true);
  await mongoose.connect(env.MONGODB_URI, { serverSelectionTimeoutMS: 10000 });
  // Ensure the email uniqueness constraint exists before accepting requests.
  await Promise.all([User.init(), Blog.init(), Session.init()]);
}
