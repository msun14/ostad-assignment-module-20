export function getProfile(req, res) {
  res.json({ success: true, data: { user: req.user } });
}

export async function updateProfile(req, res) {
  Object.assign(req.user, req.validated.body);
  await req.user.save();
  res.json({ success: true, message: 'Profile updated', data: { user: req.user } });
}
