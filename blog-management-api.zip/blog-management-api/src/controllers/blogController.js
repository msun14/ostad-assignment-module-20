import { Blog } from '../models/Blog.js';
import { ApiError } from '../utils/ApiError.js';

export async function createBlog(req, res) {
  const blog = await Blog.create({ ...req.validated.body, creator: req.user._id });
  res.status(201).json({ success: true, message: 'Blog created', data: { blog } });
}

export async function getAllBlogs(req, res) {
  const { page, limit, tag } = req.validated.query;
  const filter = tag ? { tags: tag } : {};
  const [blogs, total] = await Promise.all([
    Blog.find(filter).sort({ createdAt: -1, _id: -1 }).skip((page - 1) * limit).limit(limit),
    Blog.countDocuments(filter),
  ]);
  res.json({ success: true, data: { blogs }, pagination: { page, limit, total, pages: Math.ceil(total / limit) } });
}

export async function getBlog(req, res) {
  const blog = await Blog.findById(req.validated.params.id);
  if (!blog) throw new ApiError(404, 'Blog not found');
  res.json({ success: true, data: { blog } });
}

async function ownedBlog(id, userId) {
  const blog = await Blog.findById(id);
  if (!blog) throw new ApiError(404, 'Blog not found');
  if (!blog.creator.equals(userId)) throw new ApiError(403, 'Only the creator can modify this blog');
  return blog;
}

export async function updateBlog(req, res) {
  const id = req.validated.params.id;
  await ownedBlog(id, req.user._id);
  // Include creator in the write filter as well as checking ownership above.
  const blog = await Blog.findOneAndUpdate({ _id: id, creator: req.user._id },
    { $set: req.validated.body }, { new: true, runValidators: true });
  if (!blog) throw new ApiError(404, 'Blog not found');
  res.json({ success: true, message: 'Blog updated', data: { blog } });
}

export async function deleteBlog(req, res) {
  const id = req.validated.params.id;
  await ownedBlog(id, req.user._id);
  const result = await Blog.deleteOne({ _id: id, creator: req.user._id });
  if (!result.deletedCount) throw new ApiError(404, 'Blog not found');
  res.json({ success: true, message: 'Blog deleted' });
}
