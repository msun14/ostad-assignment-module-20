import bcrypt from 'bcryptjs';
import { User } from '../models/User.js';
import { Session } from '../models/Session.js';
import { ApiError } from '../utils/ApiError.js';
import { startSession } from '../utils/session.js';
import { cookieName, cookieOptions } from '../config/env.js';

// Equal-cost password comparison even when the email does not exist.
const dummyHash = await bcrypt.hash('not-a-real-user-password', 12);

export async function register(req, res) {
  const data = req.validated.body;
  const password = await bcrypt.hash(data.password, 12);
  const user = await User.create({ ...data, password });
  res.status(201).json({ success: true, message: 'Registration successful. Please log in.', data: { user } });
}

export async function login(req, res) {
  const { email, password } = req.validated.body;
  const user = await User.findOne({ email }).select('+password');
  const matches = await bcrypt.compare(password, user?.password || dummyHash);
  if (!user || !matches) throw new ApiError(401, 'Invalid email or password');
  const csrfToken = await startSession(user, res);
  res.json({ success: true, message: 'Login successful', data: { user, csrfToken } });
}

export async function logout(req, res) {
  await Session.deleteOne({ _id: req.authSession._id, user: req.user._id });
  res.clearCookie(cookieName, cookieOptions);
  res.json({ success: true, message: 'Logged out successfully' });
}

export function getCsrf(req, res) {
  res.json({ success: true, data: { csrfToken: req.authSession.csrfToken } });
}
