import { z } from 'zod';

const name = z.string().trim().min(2).max(80);
const email = z.string().trim().toLowerCase().email().max(254);
const phoneNumber = z.string().trim().regex(/^\+?[0-9]{7,15}$/, 'Use 7–15 digits, with an optional leading +');
const password = z.string().min(8).refine(value => Buffer.byteLength(value, 'utf8') <= 72, 'Password must not exceed 72 UTF-8 bytes');
const imageUrl = z.string().trim().url().max(2048).refine(value => {
  const url = new URL(value);
  return ['http:', 'https:'].includes(url.protocol) && !url.username && !url.password;
}, 'blogImage must be an http(s) image URL without credentials');
const blogFields = {
  title: z.string().trim().min(1).max(200),
  content: z.string().trim().min(1).max(50000),
  authorName: name,
  tags: z.array(z.string().trim().toLowerCase().min(1).max(30)).max(10)
    .transform(tags => [...new Set(tags)]),
  blogImage: imageUrl,
};
const notEmpty = value => Object.keys(value).length > 0;

export const registerSchema = z.object({ name, email, password, phoneNumber }).strict();
export const loginSchema = z.object({ email, password: z.string().min(1).refine(value => Buffer.byteLength(value, 'utf8') <= 72, 'Password must not exceed 72 UTF-8 bytes') }).strict();
export const profileSchema = z.object({ name, email, phoneNumber }).partial().strict().refine(notEmpty, 'Provide at least one profile field');
export const createBlogSchema = z.object({ ...blogFields, tags: blogFields.tags.default([]) }).strict();
export const updateBlogSchema = z.object(blogFields).partial().strict().refine(notEmpty, 'Provide at least one blog field');
export const idSchema = z.object({ id: z.string().regex(/^[a-fA-F0-9]{24}$/, 'Invalid blog ID') }).strict();
export const listBlogsSchema = z.object({
  page: z.coerce.number().int().min(1).max(100000).default(1),
  limit: z.coerce.number().int().min(1).max(100).default(10),
  tag: z.string().trim().toLowerCase().min(1).max(30).optional(),
}).strict();
