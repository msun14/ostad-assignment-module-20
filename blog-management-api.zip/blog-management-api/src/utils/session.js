import { randomBytes } from 'node:crypto';
import jwt from 'jsonwebtoken';
import { Session } from '../models/Session.js';
import { env, cookieName, cookieOptions } from '../config/env.js';

export async function startSession(user, res) {
  const csrfToken = randomBytes(32).toString('hex');
  const session = await Session.create({
    user: user._id, csrfToken, expiresAt: new Date(Date.now() + env.JWT_TTL_SECONDS * 1000),
  });
  const token = jwt.sign({ sid: session._id.toString() }, env.JWT_SECRET, {
    algorithm: 'HS256', subject: user._id.toString(), issuer: 'blog-management-api',
    audience: 'blog-management-client', expiresIn: env.JWT_TTL_SECONDS,
  });
  res.cookie(cookieName, token, { ...cookieOptions, maxAge: env.JWT_TTL_SECONDS * 1000 });
  return csrfToken;
}
